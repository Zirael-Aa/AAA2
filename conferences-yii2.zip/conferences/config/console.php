<?php
return [
    'id' => 'conferences-console',
    'basePath' => dirname(__DIR__),
    'controllerNamespace' => 'app\commands',
    'language' => 'ru-RU',
    'timeZone' => 'Europe/Moscow',
    'components' => [
        'db' => require __DIR__ . '/db.php',
        'cache' => ['class' => 'yii\caching\FileCache'],
        'log' => ['targets' => [['class' => 'yii\log\FileTarget', 'levels' => ['error', 'warning']]]],
    ],
];
