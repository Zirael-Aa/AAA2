<?php
return [
    'id' => 'conferences',
    'name' => 'Конференции.РФ',
    'basePath' => dirname(__DIR__),
    'bootstrap' => ['log'],
    'language' => 'ru-RU',
    'timeZone' => 'Europe/Moscow',
    'defaultRoute' => 'site/index',
    'components' => [
        'request' => ['cookieValidationKey' => getenv('COOKIE_KEY') ?: 'conf-2027-change-this-key-before-deploy'],
        'cache' => ['class' => 'yii\caching\FileCache'],
        'user' => ['identityClass' => 'app\models\User', 'loginUrl' => ['site/login'], 'enableAutoLogin' => false],
        'session' => ['name' => 'CONFSESS'],
        'errorHandler' => ['errorAction' => 'site/error'],
        'urlManager' => ['enablePrettyUrl' => true, 'showScriptName' => false, 'rules' => []],
        'db' => require __DIR__ . '/db.php',
        'log' => ['targets' => [['class' => 'yii\log\FileTarget', 'levels' => ['error', 'warning']]]],
    ],
];
