<?php
// Параметры БД можно переопределить переменными окружения (удобно при переносе на Open Server).
return [
    'class' => 'yii\db\Connection',
    'dsn' => getenv('DB_DSN') ?: 'mysql:host=127.0.0.1;dbname=conferences',
    'username' => getenv('DB_USER') ?: 'root',
    'password' => getenv('DB_PASS') ?: '',
    'charset' => 'utf8mb4',
    'enableSchemaCache' => false,
];
