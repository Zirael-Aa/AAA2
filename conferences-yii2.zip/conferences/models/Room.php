<?php
namespace app\models;

use yii\db\ActiveRecord;

class Room extends ActiveRecord
{
    public static function tableName() { return 'room'; }

    public static function types()
    {
        return ['auditorium' => 'Аудитория', 'coworking' => 'Коворкинг', 'cinema' => 'Кинозал'];
    }

    /** Помещения, занятые на дату: есть заявка со статусом «Мероприятие назначено». */
    public static function busyIds($date)
    {
        if (!$date || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) return [];
        return array_map('intval', Request::find()->select('room_id')
            ->where(['start_date' => $date, 'status' => Request::ST_ASSIGNED])->column());
    }
}
