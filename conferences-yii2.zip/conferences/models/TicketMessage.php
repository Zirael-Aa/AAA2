<?php
namespace app\models;

use yii\db\ActiveRecord;

class TicketMessage extends ActiveRecord
{
    public static function tableName() { return 'ticket_message'; }

    public function rules()
    {
        return [['body', 'required', 'message' => 'Введите текст сообщения.'], ['body', 'string', 'max' => 5000]];
    }

    public function attributeLabels() { return ['body' => 'Сообщение']; }

    public function beforeSave($insert)
    {
        if ($insert) $this->created_at = date('Y-m-d H:i:s');
        return parent::beforeSave($insert);
    }

    public function getUser() { return $this->hasOne(User::class, ['id' => 'user_id']); }
}
