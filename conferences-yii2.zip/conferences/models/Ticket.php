<?php
namespace app\models;

use yii\db\ActiveRecord;

class Ticket extends ActiveRecord
{
    const ST_NEW = 'new', ST_PROGRESS = 'in_progress', ST_WAIT = 'waiting', ST_RESOLVED = 'resolved', ST_CLOSED = 'closed';

    public static function tableName() { return 'ticket'; }

    public static function categories()
    {
        return ['booking' => 'Бронирование помещений', 'account' => 'Учётная запись и доступ', 'payment' => 'Оплата',
            'tech' => 'Сбой в работе сайта', 'other' => 'Другое'];
    }

    /** Маршрутизация: категория → очередь поддержки. */
    public static function queues()
    {
        return ['booking' => 'L1 · Бронирование', 'account' => 'L1 · Доступ', 'payment' => 'L1 · Финансы',
            'tech' => 'L2 · Техническая', 'other' => 'L1 · Общая'];
    }

    const QUEUE_ESCALATION = 'L3 · Эскалация';

    /** Приоритет → [название, SLA в часах]. */
    public static function priorities()
    {
        return ['low' => ['Низкий', 72], 'normal' => ['Обычный', 24], 'high' => ['Высокий', 8], 'critical' => ['Критичный', 2]];
    }

    public static function statuses()
    {
        return [self::ST_NEW => 'Новая', self::ST_PROGRESS => 'В работе', self::ST_WAIT => 'Ждём ответа пользователя',
            self::ST_RESOLVED => 'Решена', self::ST_CLOSED => 'Закрыта'];
    }

    public static function priorityLabel($p) { return self::priorities()[$p][0] ?? $p; }

    public function rules()
    {
        return [
            [['subject', 'category', 'priority'], 'required', 'message' => 'Заполните поле «{attribute}».'],
            ['subject', 'string', 'min' => 5, 'max' => 150],
            ['category', 'in', 'range' => array_keys(self::categories())],
            ['priority', 'in', 'range' => array_keys(self::priorities())],
        ];
    }

    public function attributeLabels()
    {
        return ['subject' => 'Тема', 'category' => 'Категория', 'priority' => 'Приоритет', 'status' => 'Статус', 'queue' => 'Очередь'];
    }

    public function beforeSave($insert)
    {
        $now = date('Y-m-d H:i:s');
        if ($insert) {
            $this->status = self::ST_NEW;
            $this->queue = $this->priority === 'critical' ? self::QUEUE_ESCALATION : self::queues()[$this->category];
            $this->sla_due = date('Y-m-d H:i:s', time() + self::priorities()[$this->priority][1] * 3600);
            $this->created_at = $now;
        }
        $this->updated_at = $now;
        return parent::beforeSave($insert);
    }

    public function isOverdue()
    {
        return !in_array($this->status, [self::ST_RESOLVED, self::ST_CLOSED], true) && strtotime($this->sla_due) < time();
    }

    public function getMessages() { return $this->hasMany(TicketMessage::class, ['ticket_id' => 'id'])->orderBy('id'); }
    public function getUser() { return $this->hasOne(User::class, ['id' => 'user_id']); }
}
