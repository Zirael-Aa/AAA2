<?php
namespace app\models;

use yii\db\ActiveRecord;

class Backup extends ActiveRecord
{
    public static function tableName() { return 'backup'; }
}
