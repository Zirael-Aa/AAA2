<?php
namespace app\models;

use yii\db\ActiveRecord;

class Request extends ActiveRecord
{
    const ST_NEW = 'new', ST_ASSIGNED = 'assigned', ST_DONE = 'done';

    public static function tableName() { return 'request'; }

    public static function statuses()
    {
        return [self::ST_NEW => 'Новая', self::ST_ASSIGNED => 'Мероприятие назначено', self::ST_DONE => 'Завершено'];
    }

    public static function payments()
    {
        return ['cash' => 'При очном посещении', 'sbp' => 'Переводом по СБП'];
    }

    public function rules()
    {
        return [
            [['room_id', 'start_date', 'payment_method'], 'required', 'message' => 'Заполните поле «{attribute}».'],
            ['room_id', 'exist', 'targetClass' => Room::class, 'targetAttribute' => 'id', 'message' => 'Выберите помещение из списка или на схеме.'],
            ['start_date', 'date', 'format' => 'php:Y-m-d', 'message' => 'Укажите дату в формате ГГГГ-ММ-ДД.'],
            ['start_date', 'compare', 'compareValue' => date('Y-m-d'), 'operator' => '>=', 'type' => 'string', 'message' => 'Дата не может быть в прошлом.'],
            ['payment_method', 'in', 'range' => array_keys(self::payments()), 'message' => 'Выберите способ оплаты.'],
            ['room_id', 'checkFree'],
        ];
    }

    public function checkFree($attr)
    {
        if (!$this->hasErrors() && in_array((int)$this->room_id, Room::busyIds($this->start_date), true)) {
            $this->addError($attr, 'Это помещение занято на выбранную дату.');
        }
    }

    public function attributeLabels()
    {
        return ['room_id' => 'Помещение', 'start_date' => 'Дата начала конференции', 'payment_method' => 'Способ оплаты', 'status' => 'Статус'];
    }

    public function beforeSave($insert)
    {
        if ($insert) {
            $this->status = self::ST_NEW;
            $this->created_at = date('Y-m-d H:i:s');
        }
        return parent::beforeSave($insert);
    }

    public function getRoom() { return $this->hasOne(Room::class, ['id' => 'room_id']); }
    public function getUser() { return $this->hasOne(User::class, ['id' => 'user_id']); }
    public function getReview() { return $this->hasOne(Review::class, ['request_id' => 'id']); }
}
