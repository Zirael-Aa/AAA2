<?php
namespace app\models;

use yii\db\ActiveRecord;

class Release extends ActiveRecord
{
    public static function tableName() { return 'release'; }

    public function rules()
    {
        return [
            [['version'], 'required', 'message' => 'Укажите номер версии.'],
            ['version', 'trim'],
            ['version', 'match', 'pattern' => '/^\d{1,3}\.\d{1,3}\.\d{1,3}$/', 'message' => 'Версия в формате MAJOR.MINOR.PATCH, например 1.2.0.'],
            ['version', 'unique', 'message' => 'Такая версия уже существует.'],
            ['notes', 'string', 'max' => 5000],
        ];
    }

    public function attributeLabels() { return ['version' => 'Версия', 'notes' => 'Что изменилось']; }

    public function beforeSave($insert)
    {
        if ($insert) $this->created_at = date('Y-m-d H:i:s');
        return parent::beforeSave($insert);
    }

    public static function currentVersion()
    {
        try {
            return static::find()->select('version')->where(['is_current' => 1])->scalar() ?: '0.0.0';
        } catch (\Throwable $e) {
            return '0.0.0';
        }
    }
}
