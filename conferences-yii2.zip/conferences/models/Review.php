<?php
namespace app\models;

use yii\db\ActiveRecord;

class Review extends ActiveRecord
{
    public $request;

    public static function tableName() { return 'review'; }

    public function rules()
    {
        return [
            [['rating', 'text'], 'required', 'message' => 'Заполните поле «{attribute}».'],
            ['rating', 'integer', 'min' => 1, 'max' => 5],
            ['text', 'string', 'min' => 5, 'max' => 2000],
        ];
    }

    public function attributeLabels() { return ['rating' => 'Оценка', 'text' => 'Отзыв']; }
}
