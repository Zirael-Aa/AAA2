<?php
namespace app\models;

use yii\base\Model;

class RegisterForm extends Model
{
    public $login, $password, $full_name, $phone, $email;

    public function rules()
    {
        return [
            [['login', 'password', 'full_name', 'phone', 'email'], 'required', 'message' => 'Поле «{attribute}» обязательно.'],
            [['login', 'full_name', 'phone', 'email'], 'trim'],
            ['login', 'match', 'pattern' => '/^[A-Za-z0-9]{6,50}$/', 'message' => 'Логин: латиница и цифры, не менее 6 символов.'],
            ['login', 'unique', 'targetClass' => User::class, 'targetAttribute' => 'login', 'message' => 'Такой логин уже занят.'],
            ['password', 'string', 'min' => 8, 'max' => 72, 'tooShort' => 'Пароль: минимум 8 символов.'],
            ['full_name', 'match', 'pattern' => '/^[А-Яа-яЁё\s]+$/u', 'message' => 'ФИО: только кириллица и пробелы.'],
            ['full_name', 'string', 'max' => 150],
            ['phone', 'match', 'pattern' => '/^8\(\d{3}\)\d{3}-\d{2}-\d{2}$/', 'message' => 'Телефон в формате 8(XXX)XXX-XX-XX.'],
            ['email', 'email', 'message' => 'Введите корректный адрес электронной почты.'],
        ];
    }

    public function attributeLabels()
    {
        return ['login' => 'Логин', 'password' => 'Пароль', 'full_name' => 'ФИО', 'phone' => 'Телефон', 'email' => 'Электронная почта'];
    }

    public function register()
    {
        if (!$this->validate()) return false;
        $u = new User();
        $u->login = $this->login;
        $u->password_hash = \Yii::$app->security->generatePasswordHash($this->password);
        $u->auth_key = \Yii::$app->security->generateRandomString(32);
        $u->full_name = $this->full_name;
        $u->phone = $this->phone;
        $u->email = $this->email;
        $u->role = 'user';
        $u->created_at = date('Y-m-d H:i:s');
        return $u->save(false);
    }
}
