<?php
namespace app\models;

use yii\base\Model;

class LoginForm extends Model
{
    public $login;
    public $password;
    private $_user = false;

    public function rules()
    {
        return [
            [['login', 'password'], 'required', 'message' => 'Поле «{attribute}» обязательно.'],
            ['password', 'checkCredentials'],
        ];
    }

    public function attributeLabels() { return ['login' => 'Логин', 'password' => 'Пароль']; }

    public function checkCredentials($attr)
    {
        if ($this->hasErrors()) return;
        $u = $this->getUser();
        if (!$u || !$u->validatePassword($this->password)) {
            $this->addError($attr, 'Неверный логин или пароль. Проверьте раскладку и регистр.');
        }
    }

    public function login()
    {
        return $this->validate() && \Yii::$app->user->login($this->getUser(), 8 * 3600);
    }

    public function getUser()
    {
        if ($this->_user === false) $this->_user = User::findOne(['login' => $this->login]);
        return $this->_user;
    }
}
