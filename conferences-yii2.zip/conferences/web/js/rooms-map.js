/* Интерактивная схема помещений (HTML5 Canvas) с поддержкой клавиатуры и озвучивания для скринридеров. */
(function () {
  'use strict';
  var canvas = document.getElementById('room-map');
  if (!canvas || !canvas.getContext) return;

  var ctx = canvas.getContext('2d');
  var select = document.getElementById('request-room_id');
  var dateInput = document.getElementById('request-start_date');
  var live = document.getElementById('room-map-status');
  var info = document.getElementById('room-info');
  var api = canvas.getAttribute('data-api');
  var TYPES = { auditorium: 'Аудитория', coworking: 'Коворкинг', cinema: 'Кинозал' };

  var rooms = [];
  var selectedId = select && select.value ? parseInt(select.value, 10) : null;
  var focusId = null;
  var hasFocus = false;

  var C = { freeFill: '#e9f0ee', freeStroke: '#2f6b5e', busyFill: '#f3e8e5', busyStroke: '#8a3b2e',
            selFill: '#d8e3f1', selStroke: '#1c3350', text: '#14202e' };

  function find(id) { for (var i = 0; i < rooms.length; i++) if (rooms[i].id === id) return rooms[i]; return null; }
  function describe(r) {
    return r.name + ', ' + TYPES[r.type] + ', мест: ' + r.capacity + ', ' + (r.busy ? 'занято на выбранную дату' : 'свободно');
  }
  function announce(text) { live.textContent = ''; setTimeout(function () { live.textContent = text; }, 40); }

  function hatch(r) {
    ctx.save();
    ctx.beginPath(); ctx.rect(r.x, r.y, r.w, r.h); ctx.clip();
    ctx.strokeStyle = 'rgba(138,59,46,.4)'; ctx.lineWidth = 1.5;
    for (var k = -r.h; k < r.w; k += 10) {
      ctx.beginPath(); ctx.moveTo(r.x + k, r.y + r.h); ctx.lineTo(r.x + k + r.h, r.y); ctx.stroke();
    }
    ctx.restore();
  }

  function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    rooms.forEach(function (r) {
      var sel = r.id === selectedId;
      ctx.fillStyle = sel ? C.selFill : (r.busy ? C.busyFill : C.freeFill);
      ctx.fillRect(r.x, r.y, r.w, r.h);
      if (r.busy && !sel) hatch(r);
      ctx.lineWidth = sel ? 5 : 2;
      ctx.strokeStyle = sel ? C.selStroke : (r.busy ? C.busyStroke : C.freeStroke);
      ctx.strokeRect(r.x, r.y, r.w, r.h);

      // подписи не зависят от цвета: статус дублируется текстом и значком
      ctx.fillStyle = r.busy && !sel ? 'rgba(255,255,255,.88)' : 'rgba(255,255,255,0)';
      ctx.fillRect(r.x + 8, r.y + 8, r.w - 16, 58);
      ctx.fillStyle = C.text; ctx.textBaseline = 'top';
      ctx.font = 'bold 17px "Segoe UI", Arial, sans-serif';
      ctx.fillText(r.name, r.x + 14, r.y + 14, r.w - 28);
      ctx.font = '14px "Segoe UI", Arial, sans-serif';
      ctx.fillText(TYPES[r.type] + ' · ' + r.capacity + ' мест', r.x + 14, r.y + 38, r.w - 28);
      ctx.font = 'bold 14px "Segoe UI", Arial, sans-serif';
      ctx.fillText(sel ? '✓ Выбрано' : (r.busy ? '✕ Занято' : '● Свободно'), r.x + 14, r.y + r.h - 26, r.w - 28);

      if (hasFocus && r.id === focusId) {
        ctx.save();
        ctx.lineWidth = 3; ctx.strokeStyle = '#fff'; ctx.strokeRect(r.x - 4, r.y - 4, r.w + 8, r.h + 8);
        ctx.setLineDash([9, 5]); ctx.strokeStyle = '#000'; ctx.strokeRect(r.x - 4, r.y - 4, r.w + 8, r.h + 8);
        ctx.restore();
      }
    });
    syncCards(); updatePreview();
  }

  function showInfo(r) {
    info.textContent = r ? describe(r) + (r.description ? '. ' + r.description : '') : 'Наведите курсор или выберите помещение на схеме.';
  }

  var cards = document.querySelectorAll('.room-card');
  var pvPhoto = document.getElementById('pv-photo'), pvImg = document.getElementById('pv-img');
  var pvName = document.getElementById('pv-name'), pvDesc = document.getElementById('pv-desc');
  var photoBase = (api || '').replace(/\/api\/rooms.*$/, '') + '/img/rooms/';
  var shownPhoto = null;

  function syncCards() {
    Array.prototype.forEach.call(cards, function (c) {
      var id = parseInt(c.getAttribute('data-id'), 10), r = find(id);
      var busy = !!(r && r.busy), sel = id === selectedId;
      c.classList.toggle('busy', busy);
      c.classList.toggle('selected', sel);
      c.setAttribute('aria-pressed', sel ? 'true' : 'false');
      c.setAttribute('aria-disabled', busy ? 'true' : 'false');
      c.querySelector('.rc-state').textContent = sel ? '✓ Выбрано' : (busy ? '✕ Занято на эту дату' : '● Свободно');
    });
  }

  function updatePreview() {
    if (!pvName) return;
    var r = find(selectedId);
    if (!r) {
      pvName.textContent = 'Зал не выбран'; pvDesc.textContent = 'Выберите зал на схеме или в списке.';
      pvPhoto.classList.add('empty'); pvImg.hidden = true; shownPhoto = null; return;
    }
    pvName.textContent = r.name;
    pvDesc.textContent = TYPES[r.type] + ', мест: ' + r.capacity + (r.description ? '. ' + r.description : '');
    if (shownPhoto !== r.id) {
      shownPhoto = r.id;
      pvPhoto.classList.add('empty'); pvImg.hidden = true;
      pvImg.onload = function () { pvPhoto.classList.remove('empty'); pvImg.hidden = false; };
      pvImg.onerror = function () { pvPhoto.classList.add('empty'); pvImg.hidden = true; };
      pvImg.alt = 'Фото: ' + r.name;
      pvImg.src = photoBase + r.id + '.jpg';
    }
  }

  Array.prototype.forEach.call(cards, function (c) {
    c.addEventListener('click', function () { choose(parseInt(c.getAttribute('data-id'), 10)); });
  });

  function choose(id) {
    var r = find(id);
    if (!r) return;
    focusId = id;
    if (r.busy) { announce(r.name + ' занято на выбранную дату, выбрать нельзя'); showInfo(r); draw(); return; }
    selectedId = id;
    if (select) select.value = String(id);
    showInfo(r); draw(); announce('Выбрано: ' + describe(r));
  }

  function hit(e) {
    var rect = canvas.getBoundingClientRect();
    var x = (e.clientX - rect.left) * canvas.width / rect.width;
    var y = (e.clientY - rect.top) * canvas.height / rect.height;
    for (var i = rooms.length - 1; i >= 0; i--) {
      var r = rooms[i];
      if (x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h) return r;
    }
    return null;
  }

  canvas.addEventListener('click', function (e) { var r = hit(e); if (r) choose(r.id); });
  canvas.addEventListener('mousemove', function (e) {
    var r = hit(e);
    canvas.style.cursor = r && !r.busy ? 'pointer' : (r ? 'not-allowed' : 'default');
    if (r) showInfo(r);
  });
  canvas.addEventListener('mouseleave', function () { showInfo(find(selectedId)); });

  function move(dir) {
    var cur = find(focusId) || rooms[0];
    if (!cur) return;
    var cx = cur.x + cur.w / 2, cy = cur.y + cur.h / 2, best = null, bestScore = Infinity;
    rooms.forEach(function (r) {
      if (r === cur) return;
      var dx = r.x + r.w / 2 - cx, dy = r.y + r.h / 2 - cy, main, side;
      if (dir === 'right') { main = dx; side = Math.abs(dy); }
      else if (dir === 'left') { main = -dx; side = Math.abs(dy); }
      else if (dir === 'down') { main = dy; side = Math.abs(dx); }
      else { main = -dy; side = Math.abs(dx); }
      if (main <= 0) return;
      var score = main + side * 2;
      if (score < bestScore) { bestScore = score; best = r; }
    });
    if (best) { focusId = best.id; draw(); showInfo(best); announce(describe(best) + (best.id === selectedId ? ', выбрано' : '')); }
  }

  canvas.addEventListener('keydown', function (e) {
    var map = { ArrowRight: 'right', ArrowLeft: 'left', ArrowDown: 'down', ArrowUp: 'up' };
    if (map[e.key]) { e.preventDefault(); move(map[e.key]); }
    else if (e.key === 'Home' && rooms.length) { e.preventDefault(); focusId = rooms[0].id; draw(); announce(describe(rooms[0])); }
    else if (e.key === 'End' && rooms.length) { e.preventDefault(); var l = rooms[rooms.length - 1]; focusId = l.id; draw(); announce(describe(l)); }
    else if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); if (focusId) choose(focusId); }
  });
  canvas.addEventListener('focus', function () {
    hasFocus = true;
    if (!focusId && rooms.length) focusId = selectedId || rooms[0].id;
    var r = find(focusId); draw();
    if (r) announce('Схема помещений. ' + describe(r) + '. Стрелки — перемещение, Enter — выбор.');
  });
  canvas.addEventListener('blur', function () { hasFocus = false; draw(); });

  if (select) select.addEventListener('change', function () {
    var id = parseInt(select.value, 10);
    var r = find(id);
    selectedId = r && !r.busy ? id : null;
    if (r) { focusId = id; showInfo(r); }
    draw();
  });

  function load() {
    var date = dateInput ? dateInput.value : '';
    fetch(api + '?date=' + encodeURIComponent(date), { credentials: 'same-origin', headers: { 'Accept': 'application/json' } })
      .then(function (res) { if (!res.ok) throw new Error(res.status); return res.json(); })
      .then(function (data) {
        rooms = data.rooms;
        var sel = find(selectedId);
        if (sel && sel.busy) {
          announce(sel.name + ' занято на выбранную дату, выбор сброшен');
          selectedId = null; if (select) select.value = '';
        }
        showInfo(find(selectedId)); draw();
      })
      .catch(function () { info.textContent = 'Не удалось загрузить схему. Выберите помещение в списке.'; });
  }

  if (dateInput) dateInput.addEventListener('change', load);
  load();
})();
