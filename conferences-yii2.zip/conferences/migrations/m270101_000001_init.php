<?php
use yii\db\Migration;

class m270101_000001_init extends Migration
{
    public function safeUp()
    {
        $o = $this->db->driverName === 'mysql' ? 'CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE=InnoDB' : null;

        $this->createTable('user', [
            'id' => $this->primaryKey(),
            'login' => $this->string(50)->notNull()->unique(),
            'password_hash' => $this->string(255)->notNull(),
            'auth_key' => $this->string(32)->notNull(),
            'full_name' => $this->string(150)->notNull(),
            'phone' => $this->string(20)->notNull(),
            'email' => $this->string(150)->notNull(),
            'role' => $this->string(10)->notNull()->defaultValue('user'),
            'created_at' => $this->dateTime()->notNull(),
        ], $o);

        $this->createTable('room', [
            'id' => $this->primaryKey(),
            'name' => $this->string(100)->notNull(),
            'type' => $this->string(20)->notNull(),
            'capacity' => $this->integer()->notNull(),
            'description' => $this->string(255),
            'x' => $this->integer()->notNull(), 'y' => $this->integer()->notNull(),
            'w' => $this->integer()->notNull(), 'h' => $this->integer()->notNull(),
        ], $o);

        $this->createTable('request', [
            'id' => $this->primaryKey(),
            'user_id' => $this->integer()->notNull(),
            'room_id' => $this->integer()->notNull(),
            'start_date' => $this->date()->notNull(),
            'payment_method' => $this->string(10)->notNull(),
            'status' => $this->string(10)->notNull()->defaultValue('new'),
            'created_at' => $this->dateTime()->notNull(),
        ], $o);
        $this->createIndex('idx_request_room_date', 'request', ['room_id', 'start_date', 'status']);
        $this->addForeignKey('fk_request_user', 'request', 'user_id', 'user', 'id', 'CASCADE');
        $this->addForeignKey('fk_request_room', 'request', 'room_id', 'room', 'id', 'CASCADE');

        $this->createTable('review', [
            'id' => $this->primaryKey(),
            'request_id' => $this->integer()->notNull()->unique(),
            'user_id' => $this->integer()->notNull(),
            'rating' => $this->smallInteger()->notNull(),
            'text' => $this->text()->notNull(),
            'created_at' => $this->dateTime()->notNull(),
        ], $o);
        $this->addForeignKey('fk_review_request', 'review', 'request_id', 'request', 'id', 'CASCADE');
        $this->addForeignKey('fk_review_user', 'review', 'user_id', 'user', 'id', 'CASCADE');

        $this->createTable('ticket', [
            'id' => $this->primaryKey(),
            'user_id' => $this->integer()->notNull(),
            'subject' => $this->string(150)->notNull(),
            'category' => $this->string(20)->notNull(),
            'priority' => $this->string(10)->notNull(),
            'status' => $this->string(15)->notNull()->defaultValue('new'),
            'queue' => $this->string(40)->notNull(),
            'assigned_to' => $this->integer(),
            'sla_due' => $this->dateTime()->notNull(),
            'created_at' => $this->dateTime()->notNull(),
            'updated_at' => $this->dateTime()->notNull(),
        ], $o);
        $this->createIndex('idx_ticket_status', 'ticket', ['status', 'queue']);
        $this->addForeignKey('fk_ticket_user', 'ticket', 'user_id', 'user', 'id', 'CASCADE');

        $this->createTable('ticket_message', [
            'id' => $this->primaryKey(),
            'ticket_id' => $this->integer()->notNull(),
            'user_id' => $this->integer()->notNull(),
            'is_staff' => $this->boolean()->notNull()->defaultValue(0),
            'body' => $this->text()->notNull(),
            'created_at' => $this->dateTime()->notNull(),
        ], $o);
        $this->addForeignKey('fk_tmsg_ticket', 'ticket_message', 'ticket_id', 'ticket', 'id', 'CASCADE');

        // Служебные таблицы: не входят в состав резервных копий данных.
        $this->createTable('backup', [
            'id' => $this->primaryKey(),
            'filename' => $this->string(64)->notNull()->unique(),
            'size' => $this->integer()->notNull(),
            'sha256' => $this->string(64)->notNull(),
            'comment' => $this->string(255),
            'created_by' => $this->integer(),
            'created_at' => $this->dateTime()->notNull(),
        ], $o);

        $this->createTable('release', [
            'id' => $this->primaryKey(),
            'version' => $this->string(20)->notNull()->unique(),
            'notes' => $this->text(),
            'backup_id' => $this->integer(),
            'is_current' => $this->boolean()->notNull()->defaultValue(0),
            'created_by' => $this->integer(),
            'created_at' => $this->dateTime()->notNull(),
        ], $o);

        $now = date('Y-m-d H:i:s');
        $sec = Yii::$app->security;
        $this->insert('user', [
            'login' => 'Conf2027', 'password_hash' => $sec->generatePasswordHash('Demo77'),
            'auth_key' => $sec->generateRandomString(32), 'full_name' => 'Администратор портала',
            'phone' => '8(900)000-00-00', 'email' => 'admin@conferences.local', 'role' => 'admin', 'created_at' => $now,
        ]);

        $rooms = [
            ['Аудитория А-101', 'auditorium', 120, 'Лекционная аудитория с проектором', 30, 30, 220, 150],
            ['Аудитория А-102', 'auditorium', 80, 'Аудитория для докладов', 270, 30, 200, 150],
            ['Кинозал «Орион»', 'cinema', 200, 'Большой зал, объёмный звук', 490, 30, 280, 220],
            ['Коворкинг «Хаб»', 'coworking', 40, 'Открытое пространство, Wi-Fi', 30, 200, 270, 130],
            ['Коворкинг «Лофт»', 'coworking', 25, 'Малый коворкинг с переговорной зоной', 320, 200, 150, 130],
            ['Аудитория Б-201', 'auditorium', 60, 'Аудитория с трансформируемой мебелью', 30, 350, 220, 130],
            ['Аудитория Б-202', 'auditorium', 90, 'Аудитория с амфитеатром', 270, 350, 200, 130],
            ['Кинозал «Сириус»', 'cinema', 150, 'Средний зал для презентаций', 490, 270, 280, 210],
        ];
        foreach ($rooms as $r) {
            $this->insert('room', array_combine(['name', 'type', 'capacity', 'description', 'x', 'y', 'w', 'h'], $r));
        }
        $this->insert('release', ['version' => '1.0.0', 'notes' => 'Первоначальный релиз', 'is_current' => 1, 'created_at' => $now]);
    }

    public function safeDown()
    {
        foreach (['release', 'backup', 'ticket_message', 'ticket', 'review', 'request', 'room', 'user'] as $t) {
            $this->dropTable($t);
        }
    }
}
