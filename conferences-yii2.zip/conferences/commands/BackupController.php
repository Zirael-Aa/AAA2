<?php
namespace app\commands;

use app\components\BackupService;
use yii\console\Controller;

/** Для cron: php yii backup/create */
class BackupController extends Controller
{
    public function actionCreate()
    {
        $b = BackupService::create(null, 'Плановая копия (cron)');
        echo "Создана копия #{$b->id} ({$b->size} байт)\n";
        return 0;
    }
}
