<?php
namespace app\controllers;

use app\components\BackupService;
use app\models\Backup;
use app\models\Release;
use app\models\Request;
use app\models\Room;
use app\models\Ticket;
use app\models\TicketMessage;
use yii\data\ActiveDataProvider;
use yii\filters\AccessControl;
use yii\filters\VerbFilter;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\web\UploadedFile;

class AdminController extends Controller
{
    public function behaviors()
    {
        return [
            'access' => ['class' => AccessControl::class, 'rules' => [[
                'allow' => true, 'roles' => ['@'],
                'matchCallback' => function () { return \Yii::$app->user->identity->isAdmin(); },
            ]]],
            'verbs' => ['class' => VerbFilter::class, 'actions' => [
                'set-status' => ['post'], 'backup-create' => ['post'], 'backup-restore' => ['post'],
                'backup-delete' => ['post'], 'backup-import' => ['post'], 'release-create' => ['post'], 'release-activate' => ['post'],
            ]],
        ];
    }

    private function flash($t, $m) { \Yii::$app->session->setFlash($t, $m); }

    /* ---------- Заявки ---------- */
    public function actionIndex()
    {
        $g = \Yii::$app->request->get();
        $q = Request::find()->joinWith(['user', 'room'])->orderBy(['request.id' => SORT_DESC]);
        $q->andFilterWhere(['request.status' => $g['status'] ?? null, 'request.room_id' => $g['room'] ?? null]);
        $q->andFilterWhere(['>=', 'request.start_date', $g['from'] ?? null]);
        $q->andFilterWhere(['<=', 'request.start_date', $g['to'] ?? null]);
        $s = trim($g['q'] ?? '');
        if ($s !== '') {
            $q->andWhere(['or', ['like', 'user.full_name', $s], ['like', 'user.login', $s]]);
        }
        $dp = new ActiveDataProvider(['query' => $q, 'pagination' => ['pageSize' => 9]]);
        return $this->render('index', ['dp' => $dp, 'g' => $g, 'rooms' => Room::find()->orderBy('id')->all()]);
    }

    public function actionSetStatus()
    {
        $r = Request::findOne((int)\Yii::$app->request->post('id'));
        $st = \Yii::$app->request->post('status');
        if (!$r) throw new NotFoundHttpException('Заявка не найдена.');
        if (!array_key_exists($st, Request::statuses())) {
            $this->flash('error', 'Недопустимый статус.');
        } elseif ($st === Request::ST_ASSIGNED && in_array((int)$r->room_id, Room::busyIds($r->start_date), true) && $r->status !== Request::ST_ASSIGNED) {
            $this->flash('error', 'Помещение уже занято другим мероприятием на эту дату.');
        } else {
            $r->status = $st;
            $r->save(false);
            $this->flash('success', "Статус заявки №{$r->id}: «" . Request::statuses()[$st] . '».');
        }
        $back = (string)\Yii::$app->request->post('back', '');
        // только локальный путь — защита от open redirect
        return $this->redirect(preg_match('#^/[^/\\\\]#', $back) ? $back : ['admin/index']);
    }

    /* ---------- Helpdesk ---------- */
    public function actionTickets()
    {
        $g = \Yii::$app->request->get();
        $q = Ticket::find()->joinWith('user')->orderBy(['ticket.sla_due' => SORT_ASC]);
        $q->andFilterWhere(['ticket.status' => $g['status'] ?? null, 'ticket.queue' => $g['queue'] ?? null, 'ticket.priority' => $g['priority'] ?? null]);
        if (empty($g['status'])) $q->andWhere(['not in', 'ticket.status', [Ticket::ST_CLOSED]]);
        $dp = new ActiveDataProvider(['query' => $q, 'pagination' => ['pageSize' => 15]]);
        return $this->render('tickets', ['dp' => $dp, 'g' => $g]);
    }

    public function actionTicket($id)
    {
        $t = Ticket::findOne($id);
        if (!$t) throw new NotFoundHttpException('Обращение не найдено.');
        $msg = new TicketMessage();
        if ($msg->load(\Yii::$app->request->post()) && $msg->validate()) {
            $st = \Yii::$app->request->post('new_status');
            $msg->ticket_id = $t->id;
            $msg->user_id = \Yii::$app->user->id;
            $msg->is_staff = 1;
            $msg->save(false);
            if (!$t->assigned_to) $t->assigned_to = \Yii::$app->user->id;
            $t->status = array_key_exists($st, Ticket::statuses()) ? $st : Ticket::ST_WAIT;
            $t->save(false);
            $this->flash('success', 'Ответ отправлен.');
            return $this->redirect(['admin/ticket', 'id' => $t->id]);
        }
        return $this->render('ticket', ['t' => $t, 'msg' => $msg]);
    }

    /* ---------- Резервные копии ---------- */
    public function actionBackups()
    {
        return $this->render('backups', ['items' => Backup::find()->orderBy(['id' => SORT_DESC])->all()]);
    }

    public function actionBackupCreate()
    {
        try {
            $b = BackupService::create(\Yii::$app->user->id, \Yii::$app->request->post('comment'));
            $this->flash('success', "Копия №{$b->id} создана.");
        } catch (\Throwable $e) {
            \Yii::error($e);
            $this->flash('error', 'Не удалось создать копию.');
        }
        return $this->redirect(['admin/backups']);
    }

    public function actionBackupDownload($id)
    {
        $b = $this->findBackup($id);
        return \Yii::$app->response->sendFile(BackupService::path($b), 'conferences-backup-' . $b->id . '.json', ['mimeType' => 'application/json']);
    }

    public function actionBackupRestore()
    {
        $b = $this->findBackup(\Yii::$app->request->post('id'));
        try {
            BackupService::restore($b, \Yii::$app->user->id);
            $this->flash('success', "Данные восстановлены из копии №{$b->id}. Перед этим создана страховочная копия.");
        } catch (\InvalidArgumentException $e) {
            $this->flash('error', $e->getMessage());
        } catch (\Throwable $e) {
            \Yii::error($e);
            $this->flash('error', 'Восстановление не выполнено, данные не изменены.');
        }
        return $this->redirect(['admin/backups']);
    }

    public function actionBackupDelete()
    {
        $b = $this->findBackup(\Yii::$app->request->post('id'));
        try {
            BackupService::delete($b);
            $this->flash('success', 'Копия удалена.');
        } catch (\Throwable $e) {
            $this->flash('error', 'Не удалось удалить копию.');
        }
        return $this->redirect(['admin/backups']);
    }

    public function actionBackupImport()
    {
        try {
            $b = BackupService::import(UploadedFile::getInstanceByName('backup_file'), \Yii::$app->user->id);
            $this->flash('success', "Файл проверен и сохранён как копия №{$b->id}. Для применения нажмите «Восстановить».");
        } catch (\InvalidArgumentException $e) {
            $this->flash('error', 'Импорт отклонён: ' . $e->getMessage());
        } catch (\Throwable $e) {
            \Yii::error($e);
            $this->flash('error', 'Импорт не выполнен.');
        }
        return $this->redirect(['admin/backups']);
    }

    private function findBackup($id)
    {
        $b = Backup::findOne((int)$id);
        if (!$b) throw new NotFoundHttpException('Копия не найдена.');
        return $b;
    }

    /* ---------- Версии релизов ---------- */
    public function actionReleases()
    {
        $m = new Release();
        return $this->render('releases', ['items' => Release::find()->orderBy(['id' => SORT_DESC])->all(), 'model' => $m]);
    }

    public function actionReleaseCreate()
    {
        $m = new Release();
        if ($m->load(\Yii::$app->request->post()) && $m->validate()) {
            $tx = \Yii::$app->db->beginTransaction();
            try {
                Release::updateAll(['is_current' => 0]);
                $m->is_current = 1;
                $m->created_by = \Yii::$app->user->id;
                $m->save(false);
                $b = BackupService::create(\Yii::$app->user->id, 'Снимок данных релиза ' . $m->version);
                $m->backup_id = $b->id;
                $m->save(false);
                $tx->commit();
                $this->flash('success', "Релиз {$m->version} зафиксирован, создана копия данных №{$b->id}.");
            } catch (\Throwable $e) {
                $tx->rollBack();
                \Yii::error($e);
                $this->flash('error', 'Не удалось зафиксировать релиз.');
            }
            return $this->redirect(['admin/releases']);
        }
        return $this->render('releases', ['items' => Release::find()->orderBy(['id' => SORT_DESC])->all(), 'model' => $m]);
    }

    /** Сделать релиз текущим; с restore=1 — ещё и откатить данные к его снимку. */
    public function actionReleaseActivate()
    {
        $r = Release::findOne((int)\Yii::$app->request->post('id'));
        if (!$r) throw new NotFoundHttpException('Релиз не найден.');
        try {
            if (\Yii::$app->request->post('restore') && $r->backup_id) {
                BackupService::restore($this->findBackup($r->backup_id), \Yii::$app->user->id);
            }
            Release::updateAll(['is_current' => 0]);
            Release::updateAll(['is_current' => 1], ['id' => $r->id]);
            $this->flash('success', "Текущая версия: {$r->version}.");
        } catch (\InvalidArgumentException $e) {
            $this->flash('error', $e->getMessage());
        } catch (\Throwable $e) {
            \Yii::error($e);
            $this->flash('error', 'Откат не выполнен.');
        }
        return $this->redirect(['admin/releases']);
    }
}
