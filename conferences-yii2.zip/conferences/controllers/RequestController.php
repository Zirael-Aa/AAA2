<?php
namespace app\controllers;

use app\models\Request;
use app\models\Review;
use app\models\Room;
use yii\filters\AccessControl;
use yii\filters\VerbFilter;
use yii\web\Controller;
use yii\web\ForbiddenHttpException;
use yii\web\NotFoundHttpException;

class RequestController extends Controller
{
    public function behaviors()
    {
        return [
            'access' => ['class' => AccessControl::class, 'rules' => [['allow' => true, 'roles' => ['@']]]],
            'verbs' => ['class' => VerbFilter::class, 'actions' => ['review' => ['post']]],
        ];
    }

    public function actionIndex()
    {
        $items = Request::find()->with(['room', 'review'])->where(['user_id' => \Yii::$app->user->id])->orderBy(['id' => SORT_DESC])->all();
        return $this->render('index', ['items' => $items]);
    }

    public function actionCreate()
    {
        $m = new Request();
        $m->user_id = \Yii::$app->user->id;
        $m->start_date = \Yii::$app->request->get('date', date('Y-m-d', strtotime('+1 day')));
        if ($m->load(\Yii::$app->request->post()) && $m->save()) {
            \Yii::$app->session->setFlash('success', 'Заявка отправлена администратору.');
            return $this->redirect(['request/index']);
        }
        $rooms = Room::find()->orderBy('id')->all();
        return $this->render('create', ['model' => $m, 'rooms' => $rooms]);
    }

    /** Отзыв доступен только владельцу и только после завершения мероприятия. */
    public function actionReview($id)
    {
        $req = Request::findOne($id);
        if (!$req || $req->user_id !== \Yii::$app->user->id) throw new NotFoundHttpException('Заявка не найдена.');
        if ($req->status !== Request::ST_DONE) throw new ForbiddenHttpException('Отзыв можно оставить после завершения мероприятия.');
        if ($req->review) {
            \Yii::$app->session->setFlash('error', 'Вы уже оставили отзыв по этой заявке.');
            return $this->redirect(['request/index']);
        }
        $r = new Review();
        if ($r->load(\Yii::$app->request->post()) && $r->validate()) {
            $r->request_id = $req->id;
            $r->user_id = \Yii::$app->user->id;
            $r->created_at = date('Y-m-d H:i:s');
            $r->save(false);
            \Yii::$app->session->setFlash('success', 'Спасибо за отзыв!');
        } else {
            \Yii::$app->session->setFlash('error', 'Отзыв не сохранён: ' . implode(' ', $r->getFirstErrors()));
        }
        return $this->redirect(['request/index']);
    }
}
