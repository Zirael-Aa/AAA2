<?php
namespace app\controllers;

use app\models\LoginForm;
use app\models\RegisterForm;
use yii\filters\VerbFilter;
use yii\web\Controller;

class SiteController extends Controller
{
    public function behaviors()
    {
        return ['verbs' => ['class' => VerbFilter::class, 'actions' => ['logout' => ['post']]]];
    }

    public function actions()
    {
        return ['error' => ['class' => 'yii\web\ErrorAction']];
    }

    public function actionIndex()
    {
        if (\Yii::$app->user->isGuest) return $this->redirect(['site/login']);
        return $this->redirect(\Yii::$app->user->identity->isAdmin() ? ['admin/index'] : ['request/index']);
    }

    public function actionLogin()
    {
        if (!\Yii::$app->user->isGuest) return $this->goHome();
        $m = new LoginForm();
        if ($m->load(\Yii::$app->request->post()) && $m->login()) return $this->goHome();
        $m->password = '';
        return $this->render('login', ['model' => $m]);
    }

    public function actionRegister()
    {
        if (!\Yii::$app->user->isGuest) return $this->goHome();
        $m = new RegisterForm();
        if ($m->load(\Yii::$app->request->post()) && $m->register()) {
            \Yii::$app->session->setFlash('success', 'Пользователь создан. Войдите, используя свой логин и пароль.');
            return $this->redirect(['site/login']);
        }
        $m->password = '';
        return $this->render('register', ['model' => $m]);
    }

    public function actionLogout()
    {
        \Yii::$app->user->logout();
        return $this->goHome();
    }
}
