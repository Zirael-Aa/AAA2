<?php
namespace app\controllers;

use app\models\Ticket;
use app\models\TicketMessage;
use yii\filters\AccessControl;
use yii\filters\VerbFilter;
use yii\web\Controller;
use yii\web\NotFoundHttpException;

/** Helpdesk: сторона пользователя. */
class TicketController extends Controller
{
    public function behaviors()
    {
        return [
            'access' => ['class' => AccessControl::class, 'rules' => [['allow' => true, 'roles' => ['@']]]],
            'verbs' => ['class' => VerbFilter::class, 'actions' => ['close' => ['post']]],
        ];
    }

    public function actionIndex()
    {
        $items = Ticket::find()->where(['user_id' => \Yii::$app->user->id])->orderBy(['id' => SORT_DESC])->all();
        return $this->render('index', ['items' => $items]);
    }

    public function actionCreate()
    {
        $t = new Ticket();
        $msg = new TicketMessage();
        $t->priority = 'normal';
        if ($t->load(\Yii::$app->request->post()) && $msg->load(\Yii::$app->request->post())) {
            $ok = $t->validate();
            $ok = $msg->validate() && $ok;
            if ($ok) {
                $tx = \Yii::$app->db->beginTransaction();
                $t->user_id = \Yii::$app->user->id;
                $t->save(false);
                $msg->ticket_id = $t->id;
                $msg->user_id = \Yii::$app->user->id;
                $msg->is_staff = 0;
                $msg->save(false);
                $tx->commit();
                \Yii::$app->session->setFlash('success', "Обращение №{$t->id} создано и передано в очередь «{$t->queue}».");
                return $this->redirect(['ticket/view', 'id' => $t->id]);
            }
        }
        return $this->render('create', ['ticket' => $t, 'msg' => $msg]);
    }

    public function actionView($id)
    {
        $t = $this->findOwn($id);
        $msg = new TicketMessage();
        if ($t->status !== Ticket::ST_CLOSED && $msg->load(\Yii::$app->request->post()) && $msg->validate()) {
            $msg->ticket_id = $t->id;
            $msg->user_id = \Yii::$app->user->id;
            $msg->is_staff = 0;
            $msg->save(false);
            $t->status = Ticket::ST_PROGRESS;   // ответ пользователя возвращает обращение в работу
            $t->save(false);
            return $this->redirect(['ticket/view', 'id' => $t->id]);
        }
        return $this->render('view', ['t' => $t, 'msg' => $msg]);
    }

    public function actionClose($id)
    {
        $t = $this->findOwn($id);
        $t->status = Ticket::ST_CLOSED;
        $t->save(false);
        \Yii::$app->session->setFlash('success', 'Обращение закрыто.');
        return $this->redirect(['ticket/index']);
    }

    private function findOwn($id)
    {
        $t = Ticket::findOne($id);
        if (!$t || $t->user_id !== \Yii::$app->user->id) throw new NotFoundHttpException('Обращение не найдено.');
        return $t;
    }
}
