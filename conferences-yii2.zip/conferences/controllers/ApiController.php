<?php
namespace app\controllers;

use app\models\Room;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\Response;

class ApiController extends Controller
{
    public function behaviors()
    {
        return ['access' => ['class' => AccessControl::class, 'rules' => [['allow' => true, 'roles' => ['@']]]]];
    }

    /** GET /api/rooms?date=YYYY-MM-DD — помещения со схемой и признаком занятости. */
    public function actionRooms($date = null)
    {
        \Yii::$app->response->format = Response::FORMAT_JSON;
        $busy = Room::busyIds($date);
        $out = [];
        foreach (Room::find()->orderBy('id')->all() as $r) {
            $out[] = ['id' => (int)$r->id, 'name' => $r->name, 'type' => $r->type, 'capacity' => (int)$r->capacity,
                'description' => $r->description, 'x' => (int)$r->x, 'y' => (int)$r->y, 'w' => (int)$r->w, 'h' => (int)$r->h,
                'busy' => in_array((int)$r->id, $busy, true)];
        }
        return ['date' => $date, 'rooms' => $out];
    }
}
