<?php
/** @var string $name @var string $label @var array $options @var string|null $value */
use yii\helpers\Html;
?>
<div class="field"><label for="f-<?= $name ?>"><?= Html::encode($label) ?></label>
<?= Html::dropDownList($name, $value, $options, ['id' => 'f-' . $name, 'class' => 'input', 'prompt' => 'Все']) ?></div>
