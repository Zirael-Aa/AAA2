<?php
use app\models\Ticket;
use yii\helpers\Html;
use yii\widgets\LinkPager;

/** @var yii\web\View $this */
/** @var yii\data\ActiveDataProvider $dp */
/** @var array $g */
$this->title = 'Поддержка';
$base = Yii::getAlias('@web');
$prio = array_map(function ($v) { return $v[0]; }, Ticket::priorities());
?>
<h1>Обращения в поддержку</h1>
<?= Html::beginForm(['admin/tickets'], 'get', ['class' => 'filters', 'role' => 'search', 'aria-label' => 'Фильтр обращений']) ?>
  <?= $this->render('_filter_select', ['name' => 'status', 'label' => 'Статус', 'options' => Ticket::statuses(), 'value' => $g['status'] ?? null]) ?>
  <?= $this->render('_filter_select', ['name' => 'queue', 'label' => 'Очередь', 'options' => array_combine(array_merge(Ticket::queues(), [Ticket::QUEUE_ESCALATION]), array_merge(Ticket::queues(), [Ticket::QUEUE_ESCALATION])), 'value' => $g['queue'] ?? null]) ?>
  <?= $this->render('_filter_select', ['name' => 'priority', 'label' => 'Приоритет', 'options' => $prio, 'value' => $g['priority'] ?? null]) ?>
  <div class="field actions"><button class="btn" type="submit">Применить</button> <a class="btn ghost" href="<?= $base ?>/admin/tickets">Сбросить</a></div>
<?= Html::endForm() ?>
<p class="muted">По умолчанию закрытые обращения скрыты; сортировка по сроку ответа (SLA).</p>
<div class="table-wrap"><table>
  <caption class="sr-only">Обращения в поддержку</caption>
  <thead><tr><th scope="col">№</th><th scope="col">Тема</th><th scope="col">Автор</th><th scope="col">Очередь</th><th scope="col">Приоритет</th><th scope="col">Статус</th><th scope="col">Срок ответа</th></tr></thead>
  <tbody>
  <?php foreach ($dp->getModels() as $t): ?>
    <tr<?= $t->isOverdue() ? ' class="overdue"' : '' ?>>
      <td><?= (int)$t->id ?></td>
      <td><a href="<?= $base ?>/admin/ticket?id=<?= (int)$t->id ?>"><?= Html::encode($t->subject) ?></a></td>
      <td><?= Html::encode($t->user->full_name) ?></td>
      <td><?= Html::encode($t->queue) ?></td>
      <td><?= Html::encode(Ticket::priorityLabel($t->priority)) ?></td>
      <td><?= Html::encode(Ticket::statuses()[$t->status]) ?></td>
      <td><?= Html::encode(Yii::$app->formatter->asDatetime($t->sla_due, 'short')) ?><?= $t->isOverdue() ? ' <strong>— просрочено</strong>' : '' ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div>
<?= LinkPager::widget(['pagination' => $dp->pagination, 'options' => ['class' => 'pager']]) ?>
