<?php
use yii\helpers\Html;

/** @var yii\web\View $this */
/** @var app\models\Backup[] $items */
$this->title = 'Резервные копии';
$base = Yii::getAlias('@web');
?>
<h1>Резервные копии базы данных</h1>
<div class="two-col">
<section class="panel">
  <h2>Создать копию</h2>
  <?= Html::beginForm(['admin/backup-create'], 'post') ?>
    <div class="field"><label for="comment">Комментарий (необязательно)</label><input id="comment" name="comment" class="input" maxlength="255"></div>
    <button class="btn" type="submit">Создать копию</button>
  <?= Html::endForm() ?>
</section>
<section class="panel">
  <h2>Импорт копии</h2>
  <?= Html::beginForm(['admin/backup-import'], 'post', ['enctype' => 'multipart/form-data']) ?>
    <div class="field"><label for="backup_file">Файл .json (до 10 МБ)</label><input id="backup_file" name="backup_file" type="file" accept=".json,application/json" class="input" required></div>
    <button class="btn" type="submit">Проверить и импортировать</button>
  <?= Html::endForm() ?>
  <p class="muted">Файл проходит проверку структуры и схемы БД и сохраняется как новая копия. Применяется только кнопкой «Восстановить».</p>
</section>
</div>
<?php if (!$items): ?><p class="empty">Копий пока нет. Создайте первую.</p><?php endif; ?>
<div class="table-wrap"><table>
  <?php if ($items): ?>
  <caption class="sr-only">Список резервных копий</caption>
  <thead><tr><th scope="col">№</th><th scope="col">Создана</th><th scope="col">Размер</th><th scope="col">Комментарий</th><th scope="col">Действия</th></tr></thead>
  <?php endif; ?>
  <tbody>
  <?php foreach ($items as $b): ?>
    <tr>
      <td><?= (int)$b->id ?></td>
      <td><?= Html::encode(Yii::$app->formatter->asDatetime($b->created_at, 'short')) ?></td>
      <td><?= Html::encode(Yii::$app->formatter->asShortSize($b->size)) ?></td>
      <td><?= Html::encode($b->comment) ?></td>
      <td class="row-actions">
        <a class="btn small ghost" href="<?= $base ?>/admin/backup-download?id=<?= (int)$b->id ?>">Скачать</a>
        <?= Html::beginForm(['admin/backup-restore'], 'post', ['class' => 'inline', 'onsubmit' => "return confirm('Заменить все данные данными из копии №" . (int)$b->id . "? Перед этим будет создана страховочная копия.')"]) ?>
          <?= Html::hiddenInput('id', $b->id) ?><button class="btn small" type="submit">Восстановить</button>
        <?= Html::endForm() ?>
        <?= Html::beginForm(['admin/backup-delete'], 'post', ['class' => 'inline', 'onsubmit' => "return confirm('Удалить копию №" . (int)$b->id . "?')"]) ?>
          <?= Html::hiddenInput('id', $b->id) ?><button class="btn small danger" type="submit">Удалить</button>
        <?= Html::endForm() ?>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div>
