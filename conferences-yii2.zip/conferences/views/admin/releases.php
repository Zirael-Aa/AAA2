<?php
use app\components\F;
use yii\helpers\Html;

/** @var yii\web\View $this */
/** @var app\models\Release[] $items */
/** @var app\models\Release $model */
$this->title = 'Версии релизов';
?>
<h1>Версии релизов</h1>
<section class="panel narrow">
  <h2>Зафиксировать новый релиз</h2>
  <?= Html::beginForm(['admin/release-create'], 'post', ['novalidate' => true]) ?>
    <?= F::field($model, 'version', 'text', ['placeholder' => '1.1.0', 'aria-required' => 'true']) ?>
    <?= F::field($model, 'notes', 'textarea', ['rows' => 3]) ?>
    <button class="btn" type="submit">Зафиксировать релиз</button>
  <?= Html::endForm() ?>
  <p class="muted">При фиксации автоматически создаётся резервная копия данных — к ней можно откатиться.</p>
</section>
<div class="table-wrap"><table>
  <caption class="sr-only">История релизов</caption>
  <thead><tr><th scope="col">Версия</th><th scope="col">Дата</th><th scope="col">Изменения</th><th scope="col">Копия</th><th scope="col">Действия</th></tr></thead>
  <tbody>
  <?php foreach ($items as $r): ?>
    <tr<?= $r->is_current ? ' class="current"' : '' ?>>
      <td><strong><?= Html::encode($r->version) ?></strong><?= $r->is_current ? ' <span class="badge">текущая</span>' : '' ?></td>
      <td><?= Html::encode(Yii::$app->formatter->asDatetime($r->created_at, 'short')) ?></td>
      <td><?= nl2br(Html::encode($r->notes)) ?></td>
      <td><?= $r->backup_id ? '№' . (int)$r->backup_id : '—' ?></td>
      <td class="row-actions">
      <?php if (!$r->is_current): ?>
        <?= Html::beginForm(['admin/release-activate'], 'post', ['class' => 'inline']) ?>
          <?= Html::hiddenInput('id', $r->id) ?><button class="btn small ghost" type="submit">Сделать текущей</button>
        <?= Html::endForm() ?>
        <?php if ($r->backup_id): ?>
        <?= Html::beginForm(['admin/release-activate'], 'post', ['class' => 'inline', 'onsubmit' => "return confirm('Откатить данные к релизу " . Html::encode($r->version) . "?')"]) ?>
          <?= Html::hiddenInput('id', $r->id) ?><?= Html::hiddenInput('restore', 1) ?><button class="btn small danger" type="submit">Откатить данные</button>
        <?= Html::endForm() ?>
        <?php endif; ?>
      <?php endif; ?>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div>
