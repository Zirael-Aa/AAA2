<?php
use app\models\Request;
use yii\helpers\ArrayHelper;
use yii\helpers\Html;
use yii\widgets\LinkPager;

/** @var yii\web\View $this */
/** @var yii\data\ActiveDataProvider $dp */
/** @var array $g */
/** @var app\models\Room[] $rooms */
$this->title = 'Заявки';
$base = Yii::getAlias('@web');
$back = Yii::$app->request->url;
?>
<h1>Заявки пользователей</h1>
<?= Html::beginForm(['admin/index'], 'get', ['class' => 'filters', 'role' => 'search', 'aria-label' => 'Фильтр заявок']) ?>
  <?= $this->render('_filter_select', ['name' => 'status', 'label' => 'Статус', 'options' => Request::statuses(), 'value' => $g['status'] ?? null]) ?>
  <?= $this->render('_filter_select', ['name' => 'room', 'label' => 'Помещение', 'options' => ArrayHelper::map($rooms, 'id', 'name'), 'value' => $g['room'] ?? null]) ?>
  <div class="field"><label for="f-from">Дата с</label><?= Html::input('date', 'from', $g['from'] ?? '', ['id' => 'f-from', 'class' => 'input']) ?></div>
  <div class="field"><label for="f-to">Дата по</label><?= Html::input('date', 'to', $g['to'] ?? '', ['id' => 'f-to', 'class' => 'input']) ?></div>
  <div class="field"><label for="f-q">Пользователь (ФИО или логин)</label><?= Html::input('text', 'q', $g['q'] ?? '', ['id' => 'f-q', 'class' => 'input']) ?></div>
  <div class="field actions"><button class="btn" type="submit">Применить</button> <a class="btn ghost" href="<?= $base ?>/admin/index">Сбросить</a></div>
<?= Html::endForm() ?>
<p class="muted">Найдено заявок: <?= (int)$dp->totalCount ?></p>
<?php if (!$dp->totalCount): ?><p class="empty">По выбранным условиям заявок нет. Сбросьте фильтр.</p><?php endif; ?>
<div class="cards">
<?php foreach ($dp->getModels() as $r): ?>
  <article class="card st-<?= Html::encode($r->status) ?>">
    <h2>№<?= (int)$r->id ?> · <?= Html::encode($r->room->name) ?></h2>
    <p class="badge"><?= Html::encode(Request::statuses()[$r->status]) ?></p>
    <dl>
      <dt>Заказчик</dt><dd><?= Html::encode($r->user->full_name) ?> (<?= Html::encode($r->user->login) ?>)</dd>
      <dt>Контакты</dt><dd><?= Html::encode($r->user->phone) ?>, <?= Html::encode($r->user->email) ?></dd>
      <dt>Дата начала</dt><dd><?= Html::encode(Yii::$app->formatter->asDate($r->start_date, 'long')) ?></dd>
      <dt>Оплата</dt><dd><?= Html::encode(Request::payments()[$r->payment_method]) ?></dd>
    </dl>
    <?= Html::beginForm(['admin/set-status'], 'post', ['class' => 'status-form']) ?>
      <?= Html::hiddenInput('id', $r->id) ?>
      <?= Html::hiddenInput('back', $back) ?>
      <label for="st<?= (int)$r->id ?>">Статус заявки №<?= (int)$r->id ?></label>
      <?= Html::dropDownList('status', $r->status, Request::statuses(), ['id' => 'st' . (int)$r->id, 'class' => 'input']) ?>
      <button class="btn small" type="submit">Сохранить</button>
    <?= Html::endForm() ?>
  </article>
<?php endforeach; ?>
</div>
<?= LinkPager::widget(['pagination' => $dp->pagination, 'options' => ['class' => 'pager']]) ?>
