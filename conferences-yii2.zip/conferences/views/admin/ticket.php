<?php
use app\components\F;
use app\models\Ticket;
use yii\helpers\Html;

/** @var yii\web\View $this */
/** @var app\models\Ticket $t */
$this->title = 'Обращение №' . $t->id;
?>
<h1>№<?= (int)$t->id ?>. <?= Html::encode($t->subject) ?></h1>
<p class="meta">Автор: <?= Html::encode($t->user->full_name) ?> (<?= Html::encode($t->user->email) ?>) · Категория: <?= Html::encode(Ticket::categories()[$t->category]) ?> · Очередь: <?= Html::encode($t->queue) ?> · Приоритет: <?= Html::encode(Ticket::priorityLabel($t->priority)) ?> · Статус: <strong><?= Html::encode(Ticket::statuses()[$t->status]) ?></strong> · Срок ответа: <?= Html::encode(Yii::$app->formatter->asDatetime($t->sla_due, 'short')) ?></p>
<?= $this->render('@app/views/ticket/_thread', ['t' => $t]) ?>
<section class="panel narrow">
  <?= Html::beginForm(['admin/ticket', 'id' => $t->id], 'post', ['novalidate' => true]) ?>
    <?= F::field($msg, 'body', 'textarea') ?>
    <div class="field"><label for="new_status">После ответа установить статус</label>
    <?= Html::dropDownList('new_status', Ticket::ST_WAIT, Ticket::statuses(), ['id' => 'new_status', 'class' => 'input']) ?></div>
    <button class="btn" type="submit">Отправить ответ</button>
  <?= Html::endForm() ?>
</section>
