<?php
use app\models\Release;
use yii\helpers\Html;

/** @var yii\web\View $this */
/** @var string $content */
$user = Yii::$app->user;
$admin = !$user->isGuest && $user->identity->isAdmin();
$base = Yii::getAlias('@web');
$cur = Yii::$app->controller ? Yii::$app->controller->route : '';
$link = function (array $routes, $label) use ($cur, $base) {
    $on = in_array($cur, $routes, true);
    return '<a href="' . $base . '/' . $routes[0] . '"' . ($on ? ' aria-current="page"' : '') . '>' . Html::encode($label) . '</a>';
};
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?= Html::csrfMetaTags() ?>
<title><?= Html::encode(($this->title ? $this->title . ' — ' : '') . 'Конференции.РФ') ?></title>
<link rel="stylesheet" href="<?= $base ?>/css/site.css">
<?php $this->head() ?>
</head>
<body>
<?php $this->beginBody() ?>
<a class="skip" href="#main">Перейти к содержимому</a>
<header class="top">
  <div class="top-in">
    <a class="brand" href="<?= $base ?>/" aria-label="Конференции.РФ — на главную">
      <!-- МЕСТО ПОД ЛОГОТИП: положите файл в web/img/logo.png -->
      <span class="logo-slot"><img src="<?= $base ?>/img/logo.png" alt="" onerror="this.parentNode.classList.add('empty');this.remove()"></span>
      <span class="brand-name">Конференции<span>.РФ</span></span>
    </a>
    <nav aria-label="Основная навигация">
      <?php if ($user->isGuest): ?>
        <?= $link(['site/login'], 'Вход') ?>
        <?= $link(['site/register'], 'Регистрация') ?>
      <?php elseif ($admin): ?>
        <?= $link(['admin/index'], 'Заявки') ?>
        <?= $link(['admin/tickets', 'admin/ticket'], 'Поддержка') ?>
        <?= $link(['admin/backups'], 'Резервные копии') ?>
        <?= $link(['admin/releases'], 'Релизы') ?>
      <?php else: ?>
        <?= $link(['request/index'], 'Мои заявки') ?>
        <?= $link(['request/create'], 'Бронирование') ?>
        <?= $link(['ticket/index', 'ticket/create', 'ticket/view'], 'Поддержка') ?>
      <?php endif; ?>
      <?php if (!$user->isGuest): ?>
        <?= Html::beginForm(['site/logout'], 'post', ['class' => 'inline']) ?>
        <button class="logout" type="submit">Выйти · <?= Html::encode($user->identity->login) ?></button>
        <?= Html::endForm() ?>
      <?php endif; ?>
    </nav>
  </div>
</header>
<main id="main" tabindex="-1">
  <div aria-live="polite">
  <?php foreach (Yii::$app->session->getAllFlashes() as $type => $msg): ?>
    <div class="flash flash-<?= Html::encode($type) ?>" role="status"><?= Html::encode(is_array($msg) ? implode(' ', $msg) : $msg) ?></div>
  <?php endforeach; ?>
  </div>
  <?= $content ?>
</main>
<footer class="foot">Конференции.РФ · версия <?= Html::encode(Release::currentVersion()) ?></footer>
<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>
