<?php
use app\components\F;
use yii\helpers\Html;

/** @var yii\web\View $this */
$this->title = 'Регистрация';
?>
<section class="panel narrow rise">
  <h1>Регистрация</h1>
  <?= Html::beginForm(['site/register'], 'post', ['novalidate' => true]) ?>
    <?= F::field($model, 'login', 'text', ['autocomplete' => 'username', 'autofocus' => true, 'aria-required' => 'true']) ?>
    <?= F::field($model, 'password', 'password', ['autocomplete' => 'new-password', 'aria-required' => 'true']) ?>
    <?= F::field($model, 'full_name', 'text', ['autocomplete' => 'name', 'aria-required' => 'true']) ?>
    <?= F::field($model, 'phone', 'tel', ['placeholder' => '8(900)123-45-67', 'autocomplete' => 'tel', 'aria-required' => 'true']) ?>
    <?= F::field($model, 'email', 'email', ['autocomplete' => 'email', 'aria-required' => 'true']) ?>
    <button class="btn" type="submit">Зарегистрироваться</button>
  <?= Html::endForm() ?>
  <p class="alt"><a href="<?= Yii::getAlias('@web') ?>/site/login">Уже зарегистрированы? Войти</a></p>
</section>
