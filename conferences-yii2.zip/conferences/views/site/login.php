<?php
use app\components\F;
use yii\helpers\Html;

/** @var yii\web\View $this */
$this->title = 'Вход';
?>
<section class="panel narrow rise">
  <h1>Вход</h1>
  <?= Html::beginForm(['site/login'], 'post', ['novalidate' => true]) ?>
    <?= F::field($model, 'login', 'text', ['autocomplete' => 'username', 'autofocus' => true]) ?>
    <?= F::field($model, 'password', 'password', ['autocomplete' => 'current-password']) ?>
    <button class="btn" type="submit">Войти</button>
  <?= Html::endForm() ?>
  <p class="alt"><a href="<?= Yii::getAlias('@web') ?>/site/register">Еще не зарегистрированы? Регистрация</a></p>
</section>
