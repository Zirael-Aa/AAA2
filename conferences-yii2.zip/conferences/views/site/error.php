<?php
use yii\helpers\Html;

/** @var yii\web\View $this */
/** @var string $name */
/** @var string $message */
$this->title = $name;
?>
<section class="panel narrow">
  <h1><?= Html::encode($name) ?></h1>
  <p><?= nl2br(Html::encode($message)) ?></p>
  <p><a href="<?= Yii::getAlias('@web') ?>/">На главную</a></p>
</section>
