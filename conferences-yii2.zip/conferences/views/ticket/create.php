<?php
use app\components\F;
use app\models\Ticket;
use yii\helpers\Html;

/** @var yii\web\View $this */
$this->title = 'Новое обращение';
$prio = [];
foreach (Ticket::priorities() as $k => $v) $prio[$k] = $v[0] . ' (ответ в течение ' . $v[1] . ' ч)';
?>
<section class="panel narrow rise">
  <h1>Новое обращение</h1>
  <?= Html::beginForm(['ticket/create'], 'post', ['novalidate' => true]) ?>
    <?= F::field($ticket, 'subject', 'text', ['aria-required' => 'true']) ?>
    <?= F::field($ticket, 'category', 'select', ['aria-required' => 'true'], Ticket::categories()) ?>
    <?= F::field($ticket, 'priority', 'select', [], $prio) ?>
    <?= F::field($msg, 'body', 'textarea', ['aria-required' => 'true']) ?>
    <button class="btn" type="submit">Отправить обращение</button>
  <?= Html::endForm() ?>
</section>
