<?php
use yii\helpers\Html;

/** @var app\models\Ticket $t */
?>
<ol class="thread">
<?php foreach ($t->messages as $m): ?>
  <li class="<?= $m->is_staff ? 'staff' : 'client' ?>">
    <p class="who"><?= $m->is_staff ? 'Поддержка' : Html::encode($m->user->full_name) ?> · <time datetime="<?= Html::encode($m->created_at) ?>"><?= Html::encode(Yii::$app->formatter->asDatetime($m->created_at, 'short')) ?></time></p>
    <p><?= nl2br(Html::encode($m->body)) ?></p>
  </li>
<?php endforeach; ?>
</ol>
