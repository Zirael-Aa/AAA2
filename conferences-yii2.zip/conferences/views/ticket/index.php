<?php
use app\models\Ticket;
use yii\helpers\Html;

/** @var yii\web\View $this */
/** @var app\models\Ticket[] $items */
$this->title = 'Поддержка';
$base = Yii::getAlias('@web');
?>
<div class="head-row"><h1>Техническая поддержка</h1><a class="btn" href="<?= $base ?>/ticket/create">Новое обращение</a></div>
<?php if (!$items): ?><p class="empty">Обращений нет. Если что-то не работает, <a href="<?= $base ?>/ticket/create">опишите проблему</a>.</p><?php endif; ?>
<div class="table-wrap"><table>
  <?php if ($items): ?><caption class="sr-only">Мои обращения</caption>
  <thead><tr><th scope="col">№</th><th scope="col">Тема</th><th scope="col">Статус</th><th scope="col">Приоритет</th><th scope="col">Срок ответа</th></tr></thead><?php endif; ?>
  <tbody>
  <?php foreach ($items as $t): ?>
    <tr>
      <td><?= (int)$t->id ?></td>
      <td><a href="<?= $base ?>/ticket/view?id=<?= (int)$t->id ?>"><?= Html::encode($t->subject) ?></a></td>
      <td><?= Html::encode(Ticket::statuses()[$t->status]) ?></td>
      <td><?= Html::encode(Ticket::priorityLabel($t->priority)) ?></td>
      <td><?= Html::encode(Yii::$app->formatter->asDatetime($t->sla_due, 'short')) ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div>
