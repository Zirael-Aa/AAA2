<?php
use app\components\F;
use app\models\Ticket;
use yii\helpers\Html;

/** @var yii\web\View $this */
/** @var app\models\Ticket $t */
$this->title = 'Обращение №' . $t->id;
?>
<div class="head-row"><h1>№<?= (int)$t->id ?>. <?= Html::encode($t->subject) ?></h1></div>
<p class="meta">Статус: <strong><?= Html::encode(Ticket::statuses()[$t->status]) ?></strong> · Очередь: <?= Html::encode($t->queue) ?> · Срок ответа: <?= Html::encode(Yii::$app->formatter->asDatetime($t->sla_due, 'short')) ?></p>
<?= $this->render('_thread', ['t' => $t]) ?>
<?php if ($t->status !== Ticket::ST_CLOSED): ?>
<section class="panel narrow">
  <?= Html::beginForm(['ticket/view', 'id' => $t->id], 'post', ['novalidate' => true]) ?>
    <?= F::field($msg, 'body', 'textarea') ?>
    <button class="btn" type="submit">Ответить</button>
  <?= Html::endForm() ?>
  <?= Html::beginForm(['ticket/close', 'id' => $t->id], 'post') ?>
    <button class="btn ghost" type="submit">Закрыть обращение</button>
  <?= Html::endForm() ?>
</section>
<?php endif; ?>
