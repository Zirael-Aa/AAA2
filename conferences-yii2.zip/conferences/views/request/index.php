<?php
use app\models\Request;
use yii\helpers\Html;

/** @var yii\web\View $this */
/** @var app\models\Request[] $items */
$this->title = 'Мои заявки';
$base = Yii::getAlias('@web');
?>
<div class="head-row"><h1>Мои заявки</h1><a class="btn" href="<?= $base ?>/request/create">Новая заявка</a></div>
<?php if (!$items): ?>
  <p class="empty">Заявок пока нет. <a href="<?= $base ?>/request/create">Выберите помещение на схеме</a> и отправьте первую.</p>
<?php endif; ?>
<div class="cards">
<?php foreach ($items as $r): ?>
  <article class="card st-<?= Html::encode($r->status) ?>">
    <h2><?= Html::encode($r->room->name) ?></h2>
    <p class="badge"><?= Html::encode(Request::statuses()[$r->status]) ?></p>
    <dl>
      <dt>Дата начала</dt><dd><?= Html::encode(Yii::$app->formatter->asDate($r->start_date, 'long')) ?></dd>
      <dt>Оплата</dt><dd><?= Html::encode(Request::payments()[$r->payment_method]) ?></dd>
    </dl>
    <?php if ($r->review): ?>
      <p class="review">Ваш отзыв (<?= (int)$r->review->rating ?>/5): <?= Html::encode($r->review->text) ?></p>
    <?php elseif ($r->status === Request::ST_DONE): ?>
      <?= Html::beginForm(['request/review', 'id' => $r->id], 'post', ['class' => 'review-form']) ?>
        <label for="rating<?= $r->id ?>">Оценка мероприятия</label>
        <select id="rating<?= $r->id ?>" name="Review[rating]" class="input">
          <?php for ($i = 5; $i >= 1; $i--): ?><option value="<?= $i ?>"><?= $i ?></option><?php endfor; ?>
        </select>
        <label for="rtext<?= $r->id ?>">Отзыв о качестве мероприятия</label>
        <textarea id="rtext<?= $r->id ?>" name="Review[text]" class="input" rows="3" required minlength="5"></textarea>
        <button class="btn small" type="submit">Отправить отзыв</button>
      <?= Html::endForm() ?>
    <?php else: ?>
      <p class="muted">Отзыв можно оставить после завершения мероприятия.</p>
    <?php endif; ?>
  </article>
<?php endforeach; ?>
</div>
