<?php
use app\components\F;
use app\models\Request;
use app\models\Room;
use yii\helpers\Html;
use yii\helpers\Url;

/** @var yii\web\View $this */
/** @var app\models\Request $model */
/** @var app\models\Room[] $rooms */
$this->title = 'Бронирование';
$base = Yii::getAlias('@web');
$items = [];
foreach ($rooms as $r) $items[$r->id] = $r->name . ' (' . Room::types()[$r->type] . ', ' . $r->capacity . ' мест)';
?>
<h1>Бронирование зала</h1>
<?= Html::beginForm(['request/create'], 'post', ['novalidate' => true, 'class' => 'booking']) ?>
  <section class="panel" aria-labelledby="s1">
    <h2 id="s1">1. Дата и оплата</h2>
    <div class="grid-2">
      <?= F::field($model, 'start_date', 'date', ['min' => date('Y-m-d'), 'aria-required' => 'true']) ?>
      <?= F::field($model, 'payment_method', 'select', ['aria-required' => 'true'], Request::payments()) ?>
    </div>
  </section>

  <section class="panel" aria-labelledby="s2">
    <h2 id="s2">2. Выбор конференц-зала</h2>
    <div class="rooms-grid" role="group" aria-label="Конференц-залы">
      <?php foreach ($rooms as $r): ?>
      <button type="button" class="room-card" data-id="<?= (int)$r->id ?>" aria-pressed="false">
        <span class="rc-photo"><img src="<?= $base ?>/img/rooms/<?= (int)$r->id ?>.jpg" alt="" loading="lazy" onerror="this.parentNode.classList.add('empty');this.remove()"></span>
        <span class="rc-body">
          <span class="rc-name"><?= Html::encode($r->name) ?></span>
          <span class="rc-meta"><?= Html::encode(Room::types()[$r->type]) ?> · <?= (int)$r->capacity ?> мест</span>
          <span class="rc-state">Свободно</span>
        </span>
      </button>
      <?php endforeach; ?>
    </div>
    <?= F::field($model, 'room_id', 'select', ['aria-required' => 'true'], $items) ?>
  </section>

  <div class="map-row">
    <section class="panel map-panel" aria-labelledby="map-title">
      <h2 id="map-title">Схема помещений</h2>
      <p id="map-help" class="muted">Клик выбирает зал. С клавиатуры: Tab — перейти на схему, стрелки — между залами, Enter или Пробел — выбрать.</p>
      <canvas id="room-map" width="800" height="510" tabindex="0" role="application"
              aria-label="Интерактивная схема помещений конференции" aria-describedby="map-help"
              data-api="<?= Html::encode(Url::to(['api/rooms'])) ?>">
        Ваш браузер не поддерживает схему. Выберите зал в списке.
      </canvas>
      <div id="room-map-status" class="sr-only" aria-live="polite"></div>
      <ul class="legend" aria-label="Условные обозначения">
        <li><span class="sw sw-free"></span>Свободно</li>
        <li><span class="sw sw-busy"></span>Занято (штриховка)</li>
        <li><span class="sw sw-sel"></span>Выбрано (✓)</li>
      </ul>
      <p id="room-info" class="room-info" aria-live="polite">Наведите курсор или выберите зал на схеме.</p>
    </section>

    <aside class="panel preview" aria-labelledby="pv-title">
      <h2 id="pv-title">Выбранный зал</h2>
      <!-- МЕСТО ПОД ФОТО ЗАЛА: web/img/rooms/<id>.jpg -->
      <div id="pv-photo" class="pv-photo empty"><img id="pv-img" alt="" hidden></div>
      <p id="pv-name" class="pv-name">Зал не выбран</p>
      <p id="pv-desc" class="muted">Выберите зал на схеме или в списке.</p>
    </aside>
  </div>

  <div class="submit-row"><button class="btn" type="submit">Отправить заявку</button></div>
<?= Html::endForm() ?>
<script src="<?= $base ?>/js/rooms-map.js"></script>
