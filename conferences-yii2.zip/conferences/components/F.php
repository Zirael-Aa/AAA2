<?php
namespace app\components;

use yii\helpers\Html;

/** Доступные поля формы: label + input + сообщение об ошибке (aria-invalid, aria-describedby, role=alert). */
class F
{
    public static function field($model, $attr, $type = 'text', $opts = [], $items = [])
    {
        $id = Html::getInputId($model, $attr);
        $err = $model->getFirstError($attr);
        $o = array_merge(['class' => 'input', 'aria-invalid' => $err ? 'true' : 'false', 'aria-describedby' => $id . '-err'], $opts);
        switch ($type) {
            case 'password': $in = Html::activePasswordInput($model, $attr, $o); break;
            case 'textarea': $in = Html::activeTextarea($model, $attr, $o + ['rows' => 5]); break;
            case 'select':
                $in = Html::activeDropDownList($model, $attr, $items, $o + ['prompt' => '— выберите —']); break;
            default: $in = Html::activeInput($type, $model, $attr, $o);
        }
        return '<div class="field' . ($err ? ' has-error' : '') . '">' . Html::activeLabel($model, $attr) . $in
            . '<div class="err" id="' . $id . '-err" role="alert">' . Html::encode($err) . '</div></div>';
    }
}
