<?php
namespace app\components;

use app\models\Backup;
use app\models\Release;
use yii\db\Query;
use yii\web\NotFoundHttpException;
use yii\web\UploadedFile;

/**
 * Резервные копии данных в формате JSON.
 *  - файлы лежат в runtime/backups (вне web-корня), имена случайные, права 0640;
 *  - скачивание/удаление/восстановление только по id записи в БД (путь из ввода пользователя не используется);
 *  - целостность проверяется SHA-256;
 *  - импорт: строгая валидация структуры, имена таблиц и колонок — по белому списку/схеме БД,
 *    вставка только через параметризованные запросы Yii (batchInsert), SQL из файла не выполняется.
 */
class BackupService
{
    const TABLES = ['user', 'room', 'request', 'review', 'ticket', 'ticket_message']; // порядок вставки (родители первыми)
    const MAX_SIZE = 10485760; // 10 МБ

    public static function dir()
    {
        $d = \Yii::getAlias('@runtime/backups');
        if (!is_dir($d)) mkdir($d, 0750, true);
        $h = $d . '/.htaccess';
        if (!is_file($h)) {
            file_put_contents($h, "<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n");
        }
        return $d;
    }

    public static function create($userId, $comment = null)
    {
        $payload = ['meta' => ['app' => 'conferences', 'created' => date('c'), 'version' => Release::currentVersion()], 'data' => []];
        foreach (self::TABLES as $t) {
            $payload['data'][$t] = (new Query())->from($t)->all();
        }
        return self::store(json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR), $userId, $comment);
    }

    private static function store($json, $userId, $comment)
    {
        $name = 'bk_' . date('Ymd_His') . '_' . bin2hex(random_bytes(8)) . '.json';
        $path = self::dir() . '/' . $name;
        if (file_put_contents($path, $json, LOCK_EX) === false) {
            throw new \RuntimeException('Не удалось записать файл копии.');
        }
        @chmod($path, 0640);
        $b = new Backup();
        $b->filename = $name;
        $b->size = strlen($json);
        $b->sha256 = hash('sha256', $json);
        $b->comment = $comment !== null ? mb_substr(trim($comment), 0, 255) : null;
        $b->created_by = $userId;
        $b->created_at = date('Y-m-d H:i:s');
        $b->save(false);
        return $b;
    }

    /** Безопасно получить путь к файлу копии и проверить целостность. */
    public static function path(Backup $b)
    {
        if (!preg_match('/^bk_\d{8}_\d{6}_[a-f0-9]{16}\.json$/', $b->filename)) {
            throw new NotFoundHttpException('Некорректное имя файла копии.');
        }
        $p = self::dir() . '/' . $b->filename;
        if (!is_file($p) || dirname(realpath($p)) !== realpath(self::dir())) {
            throw new NotFoundHttpException('Файл копии не найден.');
        }
        if (!hash_equals($b->sha256, hash_file('sha256', $p))) {
            throw new \InvalidArgumentException('Контрольная сумма не совпала: файл копии изменён или повреждён.');
        }
        return $p;
    }

    public static function delete(Backup $b)
    {
        $p = self::path($b);
        @unlink($p);
        $b->delete();
    }

    /** Разобрать и проверить содержимое копии. Возвращает payload или бросает InvalidArgumentException. */
    public static function parse($raw)
    {
        $p = json_decode($raw, true);
        if (!is_array($p) || ($p['meta']['app'] ?? null) !== 'conferences' || !isset($p['data']) || !is_array($p['data'])) {
            throw new \InvalidArgumentException('Файл не является резервной копией портала.');
        }
        $clean = ['meta' => ['app' => 'conferences', 'created' => (string)($p['meta']['created'] ?? ''), 'version' => (string)($p['meta']['version'] ?? '')], 'data' => []];
        foreach (self::TABLES as $t) {
            if (!isset($p['data'][$t]) || !is_array($p['data'][$t])) {
                throw new \InvalidArgumentException("В копии нет таблицы «{$t}».");
            }
            $cols = \Yii::$app->db->getTableSchema($t, true)->columnNames;
            $rows = [];
            foreach (array_values($p['data'][$t]) as $r) {
                if (!is_array($r) || !$r) {
                    throw new \InvalidArgumentException("Некорректная строка в таблице «{$t}».");
                }
                if (array_diff(array_keys($r), $cols) || array_diff($cols, array_keys($r))) {
                    throw new \InvalidArgumentException("Столбцы таблицы «{$t}» не совпадают со схемой БД.");
                }
                $row = [];
                foreach ($cols as $c) {
                    if (!is_null($r[$c]) && !is_scalar($r[$c])) {
                        throw new \InvalidArgumentException("Недопустимое значение в «{$t}.{$c}».");
                    }
                    $row[$c] = $r[$c];
                }
                $rows[] = $row;
            }
            $clean['data'][$t] = $rows;
        }
        return $clean;
    }

    public static function restore(Backup $b, $userId)
    {
        $payload = self::parse(file_get_contents(self::path($b)));
        self::create($userId, 'Автокопия перед восстановлением из копии #' . $b->id);
        $db = \Yii::$app->db;
        $tr = $db->beginTransaction();
        try {
            $db->createCommand('SET FOREIGN_KEY_CHECKS=0')->execute();
            foreach (array_reverse(self::TABLES) as $t) {
                $db->createCommand()->delete($t)->execute();
            }
            foreach (self::TABLES as $t) {
                $rows = $payload['data'][$t];
                if (!$rows) continue;
                $cols = array_keys($rows[0]);
                foreach (array_chunk($rows, 200) as $chunk) {
                    $db->createCommand()->batchInsert($t, $cols, array_map('array_values', $chunk))->execute();
                }
            }
            $db->createCommand('SET FOREIGN_KEY_CHECKS=1')->execute();
            $tr->commit();
        } catch (\Throwable $e) {
            $tr->rollBack();
            $db->createCommand('SET FOREIGN_KEY_CHECKS=1')->execute();
            throw $e;
        }
    }

    /** Импорт загруженного файла как новой копии (без автоматического восстановления). */
    public static function import(UploadedFile $f, $userId, $comment = null)
    {
        if (!$f || $f->hasError) throw new \InvalidArgumentException('Файл не загружен.');
        if (strtolower($f->extension) !== 'json') throw new \InvalidArgumentException('Допустим только файл .json.');
        if ($f->size > self::MAX_SIZE) throw new \InvalidArgumentException('Файл больше 10 МБ.');
        $payload = self::parse(file_get_contents($f->tempName));
        $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
        return self::store($json, $userId, $comment ?: 'Импорт: ' . mb_substr(basename($f->name), 0, 80));
    }
}
